import fs from 'node:fs/promises'
import path from 'node:path'
const slug = s => /^[a-z0-9_][a-z0-9_-]{0,47}$/.test(s)
async function scan(root, rel = '') {
  const out = []
  for (const e of await fs.readdir(path.join(root, rel), { withFileTypes: true })) {
    if (e.name.startsWith('.') || e.name === 'node_modules') continue
    if (e.isSymbolicLink()) throw 'Symlink plugin ditolak.'
    const id = rel ? rel + '/' + e.name : e.name
    if (e.isDirectory()) out.push(...await scan(root, id))
    else if (e.isFile() && e.name.endsWith('.js')) out.push(id)
  }
  return out.sort()
}
async function find(root, input) {
  const tokens = String(input ?? '').toLowerCase().replace(/\.js$/, '').split('/')
  if (tokens.length > 2 || !tokens.every(slug)) throw 'Nama plugin tidak valid. Gunakan nama atau kategori/nama.'
  const hit = (await scan(root)).filter(id => tokens.length === 2 ? id.toLowerCase() === tokens.join('/') + '.js' : path.basename(id, '.js').toLowerCase() === tokens[0])
  if (hit.length > 1) throw `Nama ambigu, gunakan kategori/nama:\n${hit.join('\n')}`
  return hit[0] ?? null
}
let handler = async (m, { conn, args }) => {
  if (conn.role === 'sub') throw 'Perintah ini hanya untuk bot utama.'
  try {
    const root = path.resolve(global.pluginLoader.root)
    if (!args[0]) throw 'Gunakan .getplugin nama atau kategori/nama.'
    const id = await find(root, args[0])
    if (!id) throw 'Plugin tidak ditemukan.'
    const file = path.join(root, id)
    if ((await fs.stat(file)).size > 512 * 1024) throw 'Plugin terlalu besar.'
    const code = await fs.readFile(file, 'utf8')
    if (code.length <= 65000) await conn.sendMessage(m.chat, { text: code }, { quoted: m })   // langsung ke socket, 1 pesan utuh
    else await conn.sendFile(m.chat, Buffer.from(code), path.basename(id), '', m, false, { mimetype: 'text/javascript' })
  } catch (e) { throw typeof e === 'string' ? e : `Operasi plugin gagal: ${e.message}` }
}
handler.help = ['getplugin <nama>']; handler.tags = ['owner']; 
handler.command = /^g(?:et)?p(?:lugin)?$/i; handler.owner = true
export default handler