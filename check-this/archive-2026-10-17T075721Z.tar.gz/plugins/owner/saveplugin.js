import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { parse } from 'acorn'
const slug = s => /^[a-z0-9_][a-z0-9_-]{0,47}$/.test(s)
async function scan(root, rel = '') {
  const out = []
  for (const e of await fs.readdir(path.join(root, rel), { withFileTypes: true })) {
    if (e.name.startsWith('.') || e.name === 'node_modules') continue
    if (e.isSymbolicLink()) throw 'Symlink plugin ditolak.'
    const id = rel ? rel + '/' + e.name : e.name
    if (e.isDirectory()) out.push(...await scan(root, id))
    else if (e.isFile() && e.name.endsWith('.js')) out.push(id)
  }
  return out.sort()
}
async function find(root, input) {
  const tokens = String(input ?? '').toLowerCase().replace(/\.js$/, '').split('/')
  if (tokens.length > 2 || !tokens.every(slug)) throw 'Nama plugin tidak valid. Gunakan nama atau kategori/nama.'
  const hit = (await scan(root)).filter(id => tokens.length === 2 ? id.toLowerCase() === tokens.join('/') + '.js' : path.basename(id, '.js').toLowerCase() === tokens[0])
  if (hit.length > 1) throw `Nama ambigu, gunakan kategori/nama:\n${hit.join('\n')}`
  return hit[0] ?? null
}
// Kategori (folder) diambil dari tag pertama: `handler.tags = ['x']` atau `export const tags = ['x']`
function firstTag(ast) {
  let tag
  for (const node of ast.body) {
    const e = node.type === 'ExpressionStatement' ? node.expression : null
    const list = e?.type === 'AssignmentExpression' && e.left.type === 'MemberExpression' && e.left.object?.name === 'handler' && e.left.property?.name === 'tags' ? e.right
      : node.type === 'ExportNamedDeclaration' ? node.declaration?.declarations?.find(d => d.id.name === 'tags')?.init : null
    if (list?.type === 'ArrayExpression') tag ??= list.elements.find(x => x?.type === 'Literal' && typeof x.value === 'string')?.value
  }
  return (tag ?? 'misc').toLowerCase()
}
let handler = async (m, { conn, args, text }) => {
  if (conn.role === 'sub') throw 'Perintah ini hanya untuk bot utama.'
  try {
    const loader = global.pluginLoader, root = path.resolve(loader.root)
    const name = args[0]?.toLowerCase().replace(/\.js$/, '')
    if (!name) throw 'Gunakan .saveplugin nama sambil membalas kode/lampiran .js.'
    if (!slug(name)) throw 'Nama plugin tidak valid. Pakai huruf kecil, angka, _ atau -, maks 48 karakter.'
    let code = m.quoted?.text || text.slice(args[0].length).trimStart()
    if (m.quoted?.mediaMessage) {
      if (m.quoted.mediaType !== 'document' || !m.quoted.msg.fileName?.endsWith('.js')) throw 'Lampiran harus .js'
      code = await m.quoted.download()
    }
    if (Buffer.isBuffer(code)) code = new TextDecoder('utf-8', { fatal: true }).decode(code)
    if (typeof code !== 'string' || !code.trim()) throw 'Gunakan .saveplugin nama sambil membalas kode/lampiran .js.'
    if (code.includes('\0') || Buffer.byteLength(code) > 512 * 1024) throw 'Kode plugin tidak valid/terlalu besar.'
    const tag = firstTag(parse(code, { sourceType: 'module', ecmaVersion: 'latest' }))
    if (!/^[a-z0-9_-]+$/.test(tag) || tag.length > 48) throw 'Tag pertama harus slug kategori.'

    const old = await find(root, name), id = `${tag}/${name}.js`, dir = path.join(root, tag), target = path.join(root, id)
    await fs.mkdir(dir, { recursive: true })
    if (await fs.realpath(dir) !== path.join(await fs.realpath(root), tag)) throw 'Folder kategori tidak valid (symlink).'
    const tmp = path.join(dir, `.${randomUUID()}.tmp`)
    await fs.writeFile(tmp, code, { mode: 0o600, flag: 'wx' })
    try { await fs.rename(tmp, target) } finally { await fs.rm(tmp, { force: true }) }

    const result = await loader.reload(id)   // hot-reload
    if (!result.ok) return m.reply(`Reload gagal: ${id}\n${result.error ?? ''}`)
    if (old && old !== id) { await fs.unlink(path.join(root, old)); await loader.remove(old) }   // pindah kategori
    await m.reply(`Tersimpan: ${id}\n${String(loader.get(id)?.command ?? 'listener')}`)
  } catch (e) { throw typeof e === 'string' ? e : `Operasi plugin gagal: ${e.message}` }
}
handler.help = ['saveplugin <nama>']; handler.tags = ['owner']; handler.command = /^saveplugin$/i; handler.owner = true
export default handler
