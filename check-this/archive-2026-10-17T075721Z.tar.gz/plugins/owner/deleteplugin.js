import fs from 'node:fs/promises'
import path from 'node:path'
const slug = s => /^[a-z0-9_][a-z0-9_-]{0,47}$/.test(s)
async function scan(root, rel = '') {
  const out = []
  for (const e of await fs.readdir(path.join(root, rel), { withFileTypes: true })) {
    if (e.name.startsWith('.') || e.name === 'node_modules') continue
    if (e.isSymbolicLink()) throw 'Symlink plugin ditolak.'
    const id = rel ? rel + '/' + e.name : e.name
    if (e.isDirectory()) out.push(...await scan(root, id))
    else if (e.isFile() && e.name.endsWith('.js')) out.push(id)
  }
  return out.sort()
}
async function find(root, input) {
  const tokens = String(input ?? '').toLowerCase().replace(/\.js$/, '').split('/')
  if (tokens.length > 2 || !tokens.every(slug)) throw 'Nama plugin tidak valid. Gunakan nama atau kategori/nama.'
  const hit = (await scan(root)).filter(id => tokens.length === 2 ? id.toLowerCase() === tokens.join('/') + '.js' : path.basename(id, '.js').toLowerCase() === tokens[0])
  if (hit.length > 1) throw `Nama ambigu, gunakan kategori/nama:\n${hit.join('\n')}`
  return hit[0] ?? null
}
let handler = async (m, { conn, args }) => {
  if (conn.role === 'sub') throw 'Perintah ini hanya untuk bot utama.'
  try {
    const loader = global.pluginLoader, root = path.resolve(loader.root)
    if (!args[0]) throw 'Gunakan .deleteplugin nama atau kategori/nama.'
    const id = await find(root, args[0])
    if (!id) throw 'Plugin tidak ditemukan.'
    const file = path.join(root, id)
    await fs.unlink(file)
    await loader.remove(id)   // lepas dari memori
    const dir = path.dirname(file)   // rapikan folder kategori yang sudah kosong
    if (dir !== root) try { await fs.rmdir(dir) } catch (e) { if (e.code !== 'ENOTEMPTY' && e.code !== 'EEXIST') throw e }
    await m.reply(`Dihapus: ${id}`)
  } catch (e) { throw typeof e === 'string' ? e : `Operasi plugin gagal: ${e.message}` }
}
handler.help = ['deleteplugin <nama>']; handler.tags = ['owner']; handler.command = /^deleteplugin$/i; handler.owner = true
export default handler
