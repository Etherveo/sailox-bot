import fs from 'node:fs/promises'
import path from 'node:path'
const PROTECTED = new Set(['sessions/creds.json'])
let handler = async (m, { conn, text }) => {
  if (conn.role === 'sub') throw 'Perintah ini hanya untuk bot utama.'
  const target = text?.trim()
  if (!target) throw 'Contoh: .deletefile tmp/sampah.txt'
  const root = process.cwd(), file = path.resolve(root, target), rel = path.relative(root, file)
  if (!rel || rel === '..' || rel.startsWith('..' + path.sep) || path.isAbsolute(rel)) throw 'Path harus berada di dalam folder bot.'
  if (PROTECTED.has(rel.split(path.sep).join('/'))) throw `File dilindungi: ${rel}`
  const stat = await fs.lstat(file).catch(() => null)
  if (!stat) throw 'File tidak ditemukan.'
  if (stat.isDirectory()) throw 'Itu folder, bukan file.'
  try { await fs.unlink(file) } catch (e) { throw `Gagal menghapus: ${e.message}` }
  await m.reply(`Terhapus: ${rel}`)
}
handler.help = ['deletefile <path>']; handler.tags = ['owner']; handler.command = /^(d(el)?(ete)?f(ile)?)$/i; handler.founder = true
export default handler